package com.stafftracker;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ReportGUI implements CommandExecutor, Listener {

    private final StaffTracker eklenti;
    private final String menuIsmi = ChatColor.DARK_GRAY + "Yetkili Raporları";

    public ReportGUI(StaffTracker eklenti) {
        this.eklenti = eklenti;
    }

    @Override
    public boolean onCommand(CommandSender gonderen, Command komut, String etiket, String[] argumanlar) {
        if (!(gonderen instanceof Player)) {
            gonderen.sendMessage(ChatColor.RED + "Bu komut sadece oyundan kullanılabilir.");
            return true;
        }

        Player oyuncu = (Player) gonderen;

        if (!oyuncu.hasPermission("stafftracker.admin")) {
            oyuncu.sendMessage(ChatColor.RED + "Bunun için yetkiniz yok.");
            return true;
        }

        if (argumanlar.length == 1 && argumanlar[0].equalsIgnoreCase("report")) {
            menuAc(oyuncu);
            return true;
        }

        oyuncu.sendMessage(ChatColor.YELLOW + "Kullanım: /stafftracker report");
        return true;
    }

    private void menuAc(Player oyuncu) {
        Inventory menu = Bukkit.createInventory(null, 54, menuIsmi);

        Bukkit.getScheduler().runTaskAsynchronously(eklenti, () -> {
            List<ItemStack> kafalar = new ArrayList<>();
            Map<UUID, StaffData> cevrilmisVeriler = eklenti.getStaffManager().getAllOfflineData();

            for (UUID uuid : eklenti.getStaffManager().getTumVeriler().keySet()) {
                if (!cevrilmisVeriler.containsKey(uuid)) {
                    cevrilmisVeriler.put(uuid, new StaffData(0, 0, 0));
                }
            }

            for (Map.Entry<UUID, StaffData> girdi : cevrilmisVeriler.entrySet()) {
                UUID uuid = girdi.getKey();
                OfflinePlayer hedef = Bukkit.getOfflinePlayer(uuid);

                long sure = girdi.getValue().getToplamSure();
                int ceza = girdi.getValue().getCezaSayisi();
                int mesaj = girdi.getValue().getMesajSayisi();

                StaffData aktifVeri = eklenti.getStaffManager().getVeri(uuid);
                if (aktifVeri != null) {
                    sure = aktifVeri.getToplamSure();
                    ceza = aktifVeri.getCezaSayisi();
                    mesaj = aktifVeri.getMesajSayisi();
                }

                ItemStack kafa = new ItemStack(Material.PLAYER_HEAD);
                SkullMeta meta = (SkullMeta) kafa.getItemMeta();
                if (meta != null) {
                    meta.setOwningPlayer(hedef);
                    meta.setDisplayName(ChatColor.AQUA + (hedef.getName() != null ? hedef.getName() : "Bilinmiyor"));

                    List<String> lore = new ArrayList<>();
                    lore.add("");
                    lore.add(ChatColor.YELLOW + "Aktiflik: " + ChatColor.WHITE + sureFormatla(sure));
                    lore.add(ChatColor.YELLOW + "Ceza Sayısı: " + ChatColor.WHITE + ceza);
                    lore.add(ChatColor.YELLOW + "Mesaj Sayısı: " + ChatColor.WHITE + mesaj);
                    lore.add("");
                    meta.setLore(lore);
                    kafa.setItemMeta(meta);
                }
                kafalar.add(kafa);
            }

            Bukkit.getScheduler().runTask(eklenti, () -> {
                for (int i = 0; i < kafalar.size() && i < 54; i++) {
                    menu.setItem(i, kafalar.get(i));
                }
                oyuncu.openInventory(menu);
            });
        });
    }

    private String sureFormatla(long toplamSaniye) {
        long saat = toplamSaniye / 3600;
        long dakika = (toplamSaniye % 3600) / 60;
        long saniye = toplamSaniye % 60;
        return saat + " Saat " + dakika + " Dakika " + saniye + " Saniye";
    }

    @EventHandler
    public void tiklama(InventoryClickEvent event) {
        if (event.getView().getTitle().equals(menuIsmi)) {
            event.setCancelled(true);
        }
    }
}
