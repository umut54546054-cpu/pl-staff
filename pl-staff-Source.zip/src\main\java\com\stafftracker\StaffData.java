package com.stafftracker;

public class StaffData {
    private long toplamSure;
    private int cezaSayisi;
    private int mesajSayisi;
    private long sonGiris;
    private boolean aktif;

    public StaffData(long toplamSure, int cezaSayisi, int mesajSayisi) {
        this.toplamSure = toplamSure;
        this.cezaSayisi = cezaSayisi;
        this.mesajSayisi = mesajSayisi;
        this.aktif = false;
    }

    public void girisYap() {
        this.sonGiris = System.currentTimeMillis();
        this.aktif = true;
    }

    public void cikisYap() {
        if (aktif) {
            long gecenSure = (System.currentTimeMillis() - sonGiris) / 1000;
            this.toplamSure += gecenSure;
            this.aktif = false;
        }
    }

    public void cezaEkle() {
        this.cezaSayisi++;
    }

    public void mesajEkle() {
        this.mesajSayisi++;
    }

    public long getToplamSure() {
        if (aktif) {
            long gecenSure = (System.currentTimeMillis() - sonGiris) / 1000;
            return toplamSure + gecenSure;
        }
        return toplamSure;
    }

    public int getCezaSayisi() {
        return cezaSayisi;
    }

    public int getMesajSayisi() {
        return mesajSayisi;
    }
}
