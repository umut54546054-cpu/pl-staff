package com.stafftracker;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class StaffManager {

    private final StaffTracker eklenti;
    private final File dosya;
    private FileConfiguration veri;
    private final Map<UUID, StaffData> yetkiliListesi;
    private final Object kilit = new Object();

    public StaffManager(StaffTracker eklenti) {
        this.eklenti = eklenti;
        this.dosya = new File(eklenti.getDataFolder(), "data.yml");
        this.yetkiliListesi = new ConcurrentHashMap<>();
        dosyaYukle();
    }

    private void dosyaYukle() {
        if (!dosya.exists()) {
            try {
                dosya.getParentFile().mkdirs();
                dosya.createNewFile();
            } catch (IOException ignored) {}
        }
        veri = YamlConfiguration.loadConfiguration(dosya);
    }

    public void veriYukle(UUID uuid) {
        Bukkit.getScheduler().runTaskAsynchronously(eklenti, () -> {
            long sure;
            int ceza;
            int mesaj;

            synchronized (kilit) {
                String yol = uuid.toString();
                sure = veri.getLong(yol + ".sure", 0L);
                ceza = veri.getInt(yol + ".ceza", 0);
                mesaj = veri.getInt(yol + ".mesaj", 0);
            }

            StaffData data = new StaffData(sure, ceza, mesaj);
            data.girisYap();
            yetkiliListesi.put(uuid, data);
        });
    }

    public void veriKaydet(UUID uuid) {
        StaffData data = yetkiliListesi.remove(uuid);
        if (data == null) return;

        data.cikisYap();
        long sonSure = data.getToplamSure();
        int sonCeza = data.getCezaSayisi();
        int sonMesaj = data.getMesajSayisi();

        Bukkit.getScheduler().runTaskAsynchronously(eklenti, () -> {
            synchronized (kilit) {
                String yol = uuid.toString();
                veri.set(yol + ".sure", sonSure);
                veri.set(yol + ".ceza", sonCeza);
                veri.set(yol + ".mesaj", sonMesaj);

                try {
                    veri.save(dosya);
                } catch (IOException ignored) {}
            }
        });
    }

    public void herkesiKaydet() {
        synchronized (kilit) {
            for (Map.Entry<UUID, StaffData> girdi : yetkiliListesi.entrySet()) {
                StaffData data = girdi.getValue();
                data.cikisYap();
                String yol = girdi.getKey().toString();
                veri.set(yol + ".sure", data.getToplamSure());
                veri.set(yol + ".ceza", data.getCezaSayisi());
                veri.set(yol + ".mesaj", data.getMesajSayisi());
            }
            try {
                veri.save(dosya);
            } catch (IOException ignored) {}
        }
        yetkiliListesi.clear();
    }

    public StaffData getVeri(UUID uuid) {
        return yetkiliListesi.get(uuid);
    }

    public Map<UUID, StaffData> getTumVeriler() {
        return yetkiliListesi;
    }

    public Map<UUID, StaffData> getAllOfflineData() {
        Map<UUID, StaffData> sonuc = new HashMap<>();
        synchronized (kilit) {
            for (String uuidString : veri.getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(uuidString);
                    long sure = veri.getLong(uuidString + ".sure", 0L);
                    int ceza = veri.getInt(uuidString + ".ceza", 0);
                    int mesaj = veri.getInt(uuidString + ".mesaj", 0);
                    sonuc.put(uuid, new StaffData(sure, ceza, mesaj));
                } catch (IllegalArgumentException ignored) {}
            }
        }
        return sonuc;
    }
}
