package com.stafftracker;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class StaffListener implements Listener {

    private final StaffTracker eklenti;

    public StaffListener(StaffTracker eklenti) {
        this.eklenti = eklenti;
    }

    @EventHandler
    public void giris(PlayerJoinEvent event) {
        Player oyuncu = event.getPlayer();
        if (oyuncu.hasPermission("stafftracker.track")) {
            eklenti.getStaffManager().veriYukle(oyuncu.getUniqueId());
        }
    }

    @EventHandler
    public void cikis(PlayerQuitEvent event) {
        Player oyuncu = event.getPlayer();
        if (oyuncu.hasPermission("stafftracker.track")) {
            eklenti.getStaffManager().veriKaydet(oyuncu.getUniqueId());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void sohbet(AsyncPlayerChatEvent event) {
        Player oyuncu = event.getPlayer();
        if (oyuncu.hasPermission("stafftracker.track")) {
            StaffData veri = eklenti.getStaffManager().getVeri(oyuncu.getUniqueId());
            if (veri != null) {
                veri.mesajEkle();
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void komut(PlayerCommandPreprocessEvent event) {
        Player oyuncu = event.getPlayer();
        if (!oyuncu.hasPermission("stafftracker.track")) return;

        String mesaj = event.getMessage().substring(1);
        String[] parcalar = mesaj.split(" ");
        String komutTam = parcalar[0].toLowerCase();
        String komut = komutTam.contains(":") ? komutTam.split(":")[1] : komutTam;

        if (komut.equals("mute") || komut.equals("tempmute") || komut.equals("ban") || komut.equals("unban") || komut.equals("kick")) {
            if (parcalar.length > 1) {
                StaffData veri = eklenti.getStaffManager().getVeri(oyuncu.getUniqueId());
                if (veri != null) {
                    veri.cezaEkle();
                }

                String hedef = parcalar[1];
                String webhookMesaji = "🛡️ **[StaffTracker]** Yetkili `" + oyuncu.getName() + "`, `" + hedef + "` isimli oyuncuyu cezalandırdı! Komut: `/" + mesaj + "`";
                eklenti.getWebhookManager().webhookGonder(webhookMesaji);
            }
        }
    }
}
