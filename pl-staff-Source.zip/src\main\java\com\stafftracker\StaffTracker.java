package com.stafftracker;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class StaffTracker extends JavaPlugin {

    private ConfigManager configManager;
    private StaffManager staffManager;
    private WebhookManager webhookManager;

    @Override
    public void onEnable() {
        configManager = new ConfigManager(this);
        staffManager = new StaffManager(this);
        webhookManager = new WebhookManager(this);

        getServer().getPluginManager().registerEvents(new StaffListener(this), this);

        ReportGUI reportGUI = new ReportGUI(this);
        getCommand("stafftracker").setExecutor(reportGUI);
        getServer().getPluginManager().registerEvents(reportGUI, this);

        for (Player oyuncu : Bukkit.getOnlinePlayers()) {
            if (oyuncu.hasPermission("stafftracker.track")) {
                staffManager.veriYukle(oyuncu.getUniqueId());
            }
        }

        getLogger().info("[StaffTracker] Eklenti aktif edildi, yetkililer takip ediliyor.");
    }

    @Override
    public void onDisable() {
        // Verileri kaydet ve belleği temizle
        staffManager.herkesiKaydet();
        getLogger().info("[StaffTracker] Eklenti deaktif edildi, veriler kaydedildi.");
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public StaffManager getStaffManager() {
        return staffManager;
    }

    public WebhookManager getWebhookManager() {
        return webhookManager;
    }
}
