package com.stafftracker;

public class ConfigManager {

    private final StaffTracker eklenti;
    private String webhookUrl;

    public ConfigManager(StaffTracker eklenti) {
        this.eklenti = eklenti;
        eklenti.saveDefaultConfig();
        yukle();
    }

    public void yukle() {
        eklenti.reloadConfig();
        this.webhookUrl = eklenti.getConfig().getString("webhook-url", "");
    }

    public String getWebhookUrl() {
        return webhookUrl;
    }
}
