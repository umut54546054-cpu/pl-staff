package com.stafftracker;

import org.bukkit.Bukkit;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class WebhookManager {

    private final StaffTracker eklenti;

    public WebhookManager(StaffTracker eklenti) {
        this.eklenti = eklenti;
    }

    public void webhookGonder(String mesaj) {
        String urlString = eklenti.getConfigManager().getWebhookUrl();
        if (urlString == null || urlString.isEmpty()) return;

        Bukkit.getScheduler().runTaskAsynchronously(eklenti, () -> {
            try {
                URL url = new URL(urlString);
                HttpURLConnection baglanti = (HttpURLConnection) url.openConnection();
                baglanti.setRequestMethod("POST");
                baglanti.setRequestProperty("Content-Type", "application/json");
                baglanti.setRequestProperty("User-Agent", "StaffTracker");
                baglanti.setDoOutput(true);

                String json = "{\"content\": \"" + mesaj.replace("\"", "\\\"") + "\"}";

                try (OutputStream os = baglanti.getOutputStream()) {
                    byte[] input = json.getBytes(StandardCharsets.UTF_8);
                    os.write(input, 0, input.length);
                }

                baglanti.getResponseCode();
                baglanti.disconnect();
            } catch (Exception e) {
                eklenti.getLogger().warning("[StaffTracker] Discord Webhook gönderilemedi: " + e.getMessage());
            }
        });
    }
}
